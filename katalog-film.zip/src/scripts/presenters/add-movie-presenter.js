import BasePresenter from "./base-presenter.js";
import MovieAPI from "../data/movie-api.js";
import LoadingUtils from "../utils/loading-utils.js";

/**
 * Add Movie Presenter - handles the logic for adding new movies
 * Mediates between AddMoviePage (View) and MovieAPI (Model)
 */
export default class AddMoviePresenter extends BasePresenter {
  constructor(view) {
    super(view, MovieAPI);
    this.selectedLocation = null;
    this.capturedPhoto = null;
    this.validationErrors = {};
  }

  async init() {
    console.log("AddMoviePresenter init called");
    this.view.initializeForm();
    console.log("initializeForm completed");
  }

  async onFormSubmit(formData) {
    try {
      console.log("Form submit started");

      // Check if user is logged in
      const isLoggedIn = this.model.isLoggedIn();
      console.log("User logged in:", isLoggedIn);

      if (!isLoggedIn) {
        this.view.showError("submit-error", "Anda harus login terlebih dahulu");
        return;
      }

      // Validate form data
      if (!this.validateFormData(formData)) {
        console.log("Validation failed:", this.validationErrors);
        this.view.showValidationErrors(this.validationErrors);
        return;
      }

      console.log("Validation passed");
      LoadingUtils.show();

      const movieData = this.prepareMovieData(formData);
      console.log("Movie data prepared:", movieData);

      const result = await this.model.addMovie(movieData);
      console.log("Movie added successfully:", result);

      this.view.showSuccess("Film berhasil ditambahkan!");

      // Set flag untuk refresh movies list
      localStorage.setItem("shouldRefreshMovies", "true");

      setTimeout(() => {
        this.view.navigateToMovies();
      }, 2000);
    } catch (error) {
      console.error("Error in onFormSubmit:", error);
      const errorMessage = error.message || "Gagal menambahkan film";
      this.view.showError("submit-error", errorMessage);
    } finally {
      console.log("Finally block - hiding loading");
      LoadingUtils.hide();
    }
  }

  validateFormData(formData) {
    this.validationErrors = {};
    let isValid = true;

    console.log("Validating form data:");

    // Validate title
    const title = formData.get("title");
    console.log("Title:", title);
    if (!title || title.trim().length === 0) {
      this.validationErrors.title = "Judul film harus diisi";
      isValid = false;
    } else if (title.trim().length < 3) {
      this.validationErrors.title = "Judul film minimal 3 karakter";
      isValid = false;
    }

    // Validate description
    const description = formData.get("description");
    console.log("Description:", description);
    if (!description || description.trim().length === 0) {
      this.validationErrors.description = "Deskripsi film harus diisi";
      isValid = false;
    } else if (description.trim().length < 10) {
      this.validationErrors.description = "Deskripsi film minimal 10 karakter";
      isValid = false;
    }

    // Validate photo
    console.log("Captured photo:", this.capturedPhoto);
    if (!this.capturedPhoto) {
      this.validationErrors.photo = "Foto film harus diambil";
      isValid = false;
    }

    console.log("Validation result:", isValid, this.validationErrors);
    return isValid;
  }

  prepareMovieData(formData) {
    const title = formData.get("title");
    const description = formData.get("description");

    // Gabungkan title dan description karena API hanya menerima description
    const fullDescription = `${title}\n\n${description}`;

    const movieData = {
      description: fullDescription,
      photo: this.capturedPhoto,
    };

    // Add location if available
    if (this.selectedLocation) {
      movieData.lat = this.selectedLocation.lat;
      movieData.lon = this.selectedLocation.lon;
    }

    return movieData;
  }

  onPhotoCaptured(photoBlob) {
    this.capturedPhoto = photoBlob;
    this.view.showPhotoPreview(photoBlob);

    if (this.validationErrors.photo) {
      delete this.validationErrors.photo;
      this.view.clearValidationError("photo");
    }
  }

  onPhotoRetake() {
    this.capturedPhoto = null;
    this.view.showCameraView();
  }

  onLocationSelected(location) {
    this.selectedLocation = location;
    this.view.updateLocationDisplay(location);
  }

  /**
   * Handle camera initialization
   */
  async onCameraInit() {
    try {
      await this.view.startCamera();
    } catch (error) {
      this.view.showError("photo-error", "Gagal mengaktifkan kamera");
    }
  }

  onFieldValidation(fieldName, value) {
    // Real-time validation
    if (fieldName === "title") {
      if (value.trim().length === 0) {
        this.validationErrors.title = "Judul film harus diisi";
      } else if (value.trim().length < 3) {
        this.validationErrors.title = "Judul film minimal 3 karakter";
      } else {
        delete this.validationErrors.title;
      }

      this.view.updateFieldValidation(fieldName, this.validationErrors.title);
    } else if (fieldName === "description") {
      if (value.trim().length === 0) {
        this.validationErrors.description = "Deskripsi film harus diisi";
      } else if (value.trim().length < 10) {
        this.validationErrors.description =
          "Deskripsi film minimal 10 karakter";
      } else {
        delete this.validationErrors.description;
      }

      this.view.updateFieldValidation(
        fieldName,
        this.validationErrors.description
      );
    }
  }

  destroy() {
    this.selectedLocation = null;
    this.capturedPhoto = null;
    this.validationErrors = {};
  }
}
