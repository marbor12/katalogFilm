const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
  MAP_API_KEY: "your_map_api_key_here", // Will be replaced with actual key
  DEFAULT_LOCATION: {
    lat: -6.2088,
    lng: 106.8456, // Jakarta coordinates
  },
}

export default CONFIG
